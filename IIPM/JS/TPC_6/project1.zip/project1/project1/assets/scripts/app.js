let resultado = 0;

function readInput(){
   const valor_digitado = parseInt(userInput.value);
    return valor_digitado;
}

function adicionar(){
    const valor_lido = readInput();

    resultado = resultado + valor_lido;
    const description  = `${resultado} + ${valor_lido}`;
    outputResult(resultado,description);
}

function multiplicar(){
    const valor_lido = readInput();

    resultado = resultado * valor_lido;
    const description  = `${resultado} * ${valor_lido}`;
    outputResult(resultado,description);
}

function subtrair(){
    const valor_lido = readInput();

    resultado = resultado - valor_lido;
    const description  = `${resultado} - ${valor_lido}`;
    outputResult(resultado,description);
}

function dividir(){
    const valor_lido = readInput();
if(valor_lido !== 0){
    resultado = resultado / valor_lido;
    const description  = `${resultado} / ${valor_lido}`;
    outputResult(resultado,description);
}else{
    alert("Erro ao dividir valor por 0");
}
}

addBtn.addEventListener("click", adicionar);
multiplyBtn.addEventListener("click", multiplicar);
subtractBtn.addEventListener("click", subtrair);
divideBtn.addEventListener("click", dividir);