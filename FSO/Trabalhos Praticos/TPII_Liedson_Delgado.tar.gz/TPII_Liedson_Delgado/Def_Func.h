#ifndef DEF_FUNC_H_INCLUDED
#define DEF_FUNC_H_INCLUDED

float notas_testes();          //funcao que solicita as notas dos 2  Testes
float notas_tg();		    //funcao que solicita as notas dos 2 Trabalhos de Grupo(escrito(5%) e escrito,oral ou experimental(20%) )
float notas_tp(); 	   //funcao que  solicita as notas dos 4 trabalhos praticos
float notas_participacao();  //funcao que solicita a contribuicao/participacao nas aulas

#endif // DEF_FUNC_H_INCLUDED
